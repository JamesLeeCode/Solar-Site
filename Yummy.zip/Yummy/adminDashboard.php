<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>W Solar Power Installer - Admin</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logo.jpg" rel="icon">
  <link href="assets/img/logo.jpg" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,600;1,700&family=Amatic+SC:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Inter:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">


</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between">

      <a href="index.html" class="logo d-flex align-items-center me-auto me-lg-0">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        
        <h1 style="font-size: 20px">W Solar Power <span> Installer</span></h1>
      </a>

      <nav id="navbar" class="navbar">
        <ul>
        </ul>
      </nav><!-- .navbar -->

      
      <i class="mobile-nav-toggle mobile-nav-show bi bi-list"></i>
      <i class="mobile-nav-toggle mobile-nav-hide d-none bi bi-x"></i>

    </div>
  </header><!-- End Header -->



  <main id="main">


    <!-- ======= Stats Counter Section ======= -->
    <section id="stats-counter" class="stats-counter">
      <div class="container" data-aos="zoom-out">

        <div class="row gy-4">

          

        </div>

      </div>
    </section><!-- End Stats Counter Section -->

    <!-- ======= Menu Section ======= -->
    <section id="shop" class="menu">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <h2>W Solar Power Installer Shop</h2>
          <p>Our Power <span>Solution Products </span></p>
        </div>

        <ul class="nav nav-tabs d-flex justify-content-center" data-aos="fade-up" data-aos-delay="200">

          <li class="nav-item">
            <a class="nav-link active show" data-bs-toggle="tab" data-bs-target="#menu-starters">
              <h4>Solar Panels</h4>
            </a>
          </li><!-- End tab nav item -->

          <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" data-bs-target="#menu-breakfast">
              <h4>Battries</h4>
            </a><!-- End tab nav item -->

          <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" data-bs-target="#menu-lunch">
              <h4>Inverters</h4>
            </a>
          </li><!-- End tab nav item -->


        </ul>

        <div class="tab-content" data-aos="fade-up" data-aos-delay="300">

          <div class="tab-pane fade active show" id="menu-starters">

            <div class="tab-header text-center">
              <p>Our Shop</p>
              <h3>Solar Panels</h3>
            </div>

            <div class="row gy-5">
             <?php
                include 'phpScripts/db_connection.php';
                $conn = OpenCon();
                $sql = "SELECT * FROM products WHERE 'type' = 'solarPanel'";
                $result = $conn->query($sql);
                //Store the results in an array
                $arr = array();
                while ($row = mysqli_fetch_assoc($result)) {
                  $arr[] = $row;
              ?> 
              <div class="col-lg-4 menu-item">
                <a href="phpScripts/upload/<?php echo  $row['img']; ?>" class="glightbox"><img src="phpScripts/upload/<?php echo  $row['img']; ?>" style="height: 250px" class="menu-img img-fluid" alt=""></a>
                <h4><?php echo  $row['name']; ?></h4>
                <p class="ingredients">
                <?php echo  $row['prod_desc']; ?>.
                </p>
                <p class="price">
                <?php echo  $row['price']; ?>
                </p>
              </div><!-- Menu Item -->
            <?php } ?>
              <div class="col-lg-4 menu-item">
                <a href="assets/img/menu/solar3.png" class="glightbox"><img src="assets/img/menu/solar3.png" style="height: 250px" class="menu-img img-fluid" alt=""></a>
                <h4>Engle Solar 545W Panel</h4>
                <p class="ingredients">
                  Module Power up to 550W, Module efficiency up to 21.5%, Up to 4.5% lower LCOE, Up to 5.6% lower system cost
                </p>
                <p class="price">
                  R4300.00
                </p>
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/menu/solar4.png" class="glightbox"><img src="assets/img/menu/solar4.png" style="height: 250px" class="menu-img img-fluid" alt=""></a>
                <h4>330W Solar Panel </h4>
                <p class="ingredients">
                  Rated Maximum Power (Mp): 330W, lerance: 0 – +_5W, Cell Efficiency: 18.70%, Open Circuit Voltage (Voc): 47.0V
                </p>
                <p class="price">
                  R2300.00
                </p>
              </div><!-- Menu Item -->

            </div>
          </div><!-- End Starter Menu Content -->

          <div class="tab-pane fade" id="menu-breakfast">

            <div class="tab-header text-center">
              <p>Our Shop</p>
              <h3>Batteries</h3>
            </div>

            <div class="row gy-5">

              <div class="col-lg-4 menu-item">
                <a href="assets/img/menu/battery.png" class="glightbox"><img src="assets/img/menu/battery.png" style="height: 250px" class="menu-img img-fluid" alt=""></a>
                <h4>24v 100ah Lithium Battery</h4>
                <p class="ingredients">
                  Brands: N energy lithium battery, Esener lithium battery, Holoselect lithium battery And many more 
                 </p>
                <p class="price">
                  R12 500
                </p>
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/menu/battery5.png" class="glightbox"><img src="assets/img/menu/battery5.png" style="height: 250px" class="menu-img img-fluid" alt=""></a>
                <h4>4.8kwt lithium battery 48v 100ah</h4>
                <p class="ingredients">
                  N energy lithium battery

                  Holoselect lithium battery

                </p>
                <p class="price">
                  R22 000
                </p>
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/menu/Battery3.png" class="glightbox"><img src="assets/img/menu/Battery3.png" style="height: 250px" class="menu-img img-fluid" alt=""></a>
                <h4>5.1kwt lithium battery 100ah 48v</h4>
                <p class="ingredients">
                 Brands: Revove R26000, Up 5000 shoto lithium battery R26900, Up 3000 shoto lithium battery 48v 100ah R25000, CFE lithium battery 100ah 48v R26000
                 </p>
                <p class="price">
                  R26 900
                </p>
              </div><!-- Menu Item -->

            </div>
          </div><!-- End Breakfast Menu Content -->

          <div class="tab-pane fade" id="menu-lunch">

            <div class="tab-header text-center">
              <p>OUR SHOP</p>
              <h3>Inverter</h3>
            </div>

            <div class="row gy-5">

              <div class="col-lg-4 menu-item">
                <a href="assets/img/menu/Inverter.png" class="glightbox"><img src="assets/img/menu/Inverter.png" style="height: 250px" class="menu-img img-fluid" alt=""></a>
                <h4>Sunsynk 5KW 1Phase Hybrid PV IP65 Inverter 48V</h4>
                <p class="ingredients">
                  220V Single Phase, Pure Sine Wave Inverter, Self Consumption and Feed-In To The Grid, Programmable Supply Priority For Battery Or Grid, Programmable Multiple Operation Modes (On-Grid / Off-Grid and UPS)
                </p>
                <p class="price">
                  R26 000
                </p>
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/menu/Inverter4.png" class="glightbox"><img src="assets/img/menu/Inverter4.png" style="height: 250px" class="menu-img img-fluid" alt=""></a>
                <h4>
                  3kva sunmagic inverter</h4>
                <p class="ingredients">
                  -24V -3000VA -220VAC -Pure sine wave inverter -Built-in solar charge controller -PWM
                   Compatible with mains voltage and can charge batteries. -Auto restart while AC is recovering -Overload and short circuit protection
                </p>
                <p class="price">
                  R5500
                </p>
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/menu/Inverter5.png" class="glightbox"><img src="assets/img/menu/Inverter2.png" style="height: 250px" class="menu-img img-fluid" alt=""></a>
                <h4>5kva luxury power inverter </h4>
                <p class="ingredients">
                  Pure sine wave inverter 5kW 5kVA MPPT 80A. Built-in 80A MPPT 48V solar charge controller. Selectable input voltage range for home appliances and personal computers.Selectable charging current based on applications
                </p>
                <p class="price">
                  R13 900
                </p>
              </div><!-- Menu Item -->
            </div>

      </div>
    </section><!-- End Menu Section -->

    <!-- ======= Events Section ======= -->
    <section id="backup" class="events">
      <div class="container-fluid" data-aos="fade-up">

        <div class="section-header">
          <h2>Backup</h2>
          <p>Our Full <span> Power Backup</span> Installations</p>
        </div>

        <div class="slides-3 swiper" data-aos="fade-up" data-aos-delay="100">
          <div class="swiper-wrapper">

            <div class="swiper-slide event-item d-flex flex-column justify-content-end" style="background-image: url(assets/img/install1.jpg)">
              <div class="price align-self-start">R49 900.00</div>
              <p class="description">
                5KVA Luxury Power Backup Installed. If installed with 6x 455w JA mono all weather Solar panels its R72 900.00  
              </p>
            </div><!-- End Event item -->

            <div class="swiper-slide event-item d-flex flex-column justify-content-end" style="background-image: url(assets/img/install2.png)">
              
              <div class="price align-self-start">R61 650.00</div>
              <p class="description">
                5KVA Deye hybrid inverter Backup Installed. If installed with 6x 455w JA mono all weather Solar panels its R84 660.00  
               </p>
            </div><!-- End Event item -->

            <div class="swiper-slide event-item d-flex flex-column justify-content-end" style="background-image: url(assets/img/install3.webp)">
            
              <div class="price align-self-start">R80 000.00</div>
              <p class="description">
                8KVA Deye 2x5.1 KWT Revove Lithium battery 100ah 48v hybrid Revove inverter Backup. If installed with 6x 455w JA mono all weather Solar panels its R119 800.00  
               </p>
            </div><!-- End Event item -->

            <div class="swiper-slide event-item d-flex flex-column justify-content-end" style="background-image: url(assets/img/install4.webp)">
            
              <div class="price align-self-start">R130 100.00</div>
              <p class="description">
                12KVA Deye 3 Phase backup with upto 5000 Shoto Lithium battery 100ah 48v x2. If installed with 12 JA mono all weather Solar panels its R188 570.00  
               </p>
            </div><!-- End Event item -->

          </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>
    </section><!-- End Events Section -->

    <!-- ======= Book A Table Section ======= -->
    <section id="book-a-table" class="book-a-table">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <h2>Add Products</h2>
          <p>Add Product<span> To </span>Database</p>
        </div>

        <div class="row g-0">

          <div class="col-lg-4 reservation-img" style="background-image: url(assets/img/cover.webp);" data-aos="zoom-out" data-aos-delay="200"></div>

          <div class="col-lg-8 d-flex align-items-center reservation-form-bg">
            <form action="phpScripts/adminOparation.php" method="multipart/form-data" role="form" class="php-email-form" data-aos="fade-up" data-aos-delay="100">
              <div class="row gy-4">
                <div class="col-lg-6 col-md-6">
                  <input type="text" class="form-control" name="type" id="type" value="addProduct" hidden>
                  <input type="text" name="name" class="form-control" id="name" placeholder="Product Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars">
                  <div class="validate"></div>
                </div>
                <div class="col-lg-6 col-md-6">
                  <input type="text" class="form-control" name="price" id="price" placeholder="Product Price" data-rule="minlen:4" data-msg="Please enter at least 4 chars">
                  <div class="validate"></div>
                </div>
                <div class="col-lg-6 col-md-6">
                  <input type="file" class="form-control" name="pic" id="pic"  >
                  <div class="validate"></div>
                </div>
                <div class="col-lg-6 col-md-6">
                  <select type="text" class="form-control" name="prodtype" id="prodtype" > 
                  <option value="Please select a type">Please select a type </option> 
                    <option value="Solar Panels">Solar Panels</option>
                    <option value="Battries">Battries</option>
                    <option value="Inverters">Inverters</option>
                  <div class="validate"></div>
                  </select>
                </div>
              
              
              <div class="form-group mt-3">
                <textarea class="form-control" name="desc" id="desc" rows="5" placeholder="Product Desc"></textarea>
                <div class="validate"></div>
              </div>
              <div class="mb-3">
                <div class="loading">Loading</div>
                <div class="error-message"></div>
                <div class="sent-message">Your booking request was sent. We will call back or send an Email to confirm your reservation. Thank you!</div>
              </div>
              <div class="text-center"><button type="submit">Add Product </button></div>
            </form>
          </div><!-- End Reservation Form -->

        </div>

      </div>
    </section><!-- End Book A Table Section -->

      <!-- ======= Book A Table Section ======= -->
      <section id="book-a-table" class="book-a-table">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <h2>Add Products</h2>
          <p>Add Product<span> To </span>Database</p>
        </div>

        <div class="row g-0">

          <div class="col-lg-4 reservation-img" style="background-image: url(assets/img/cover.webp);" data-aos="zoom-out" data-aos-delay="200"></div>

          <div class="col-lg-8 d-flex align-items-center reservation-form-bg">
            <form action="forms/book-a-table.php" method="post" role="form" class="php-email-form" data-aos="fade-up" data-aos-delay="100">
              <div class="row gy-4">
                <div class="col-lg-6 col-md-6">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Product Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars">
                  <div class="validate"></div>
                </div>
                <div class="col-lg-6 col-md-6">
                  <input type="text" class="form-control" name="price" id="price" placeholder="Product Price" data-rule="minlen:4" data-msg="Please enter at least 4 chars">
                  <div class="validate"></div>
                </div>
                <div class="col-lg-6 col-md-6">
                  <input type="file" class="form-control" name="pic" id="pic"  >
                  <div class="validate"></div>
                </div>
                <div class="col-lg-6 col-md-6">
                  <select type="text" class="form-control" name="prodtype" id="prodtype" > 
                  <option value="volvo">Please select a type </option> 
                    <option value="volvo">Solar Panels </option>
                    <option value="saab">Battries</option>
                    <option value="mercedes">Inverters</option>
                  <div class="validate"></div>
                  </select>
                </div>
              
              
              <div class="form-group mt-3">
                <textarea class="form-control" name="prod_desc" id="prod_desc" rows="5" placeholder="Product Desc"></textarea>
                <div class="validate"></div>
              </div>
              <div class="mb-3">
                <div class="loading">Loading</div>
                <div class="error-message"></div>
                <div class="sent-message">Your booking request was sent. We will call back or send an Email to confirm your reservation. Thank you!</div>
              </div>
              <div class="text-center"><button type="submit">Add Products </button></div>
            </form>
          </div><!-- End Reservation Form -->

        </div>

      </div>
    </section><!-- End Book A Table Section -->


  
  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">

    <div class="container">
      <div class="row gy-3">
        <div class="col-lg-3 col-md-6 d-flex">
          <i class="bi bi-geo-alt icon"></i>
          <div>
            <h4>Address</h4>
            <p>
              A108 Adam Street <br>
              New York, NY 535022 - US<br>
            </p>
          </div>

        </div>

        <div class="col-lg-3 col-md-6 footer-links d-flex">
          <i class="bi bi-telephone icon"></i>
          <div>
            <h4>Reservations</h4>
            <p>
              <strong>Phone:</strong> +1 5589 55488 55<br>
              <strong>Email:</strong> info@example.com<br>
            </p>
          </div>
        </div>

        <div class="col-lg-3 col-md-6 footer-links d-flex">
          <i class="bi bi-clock icon"></i>
          <div>
            <h4>Opening Hours</h4>
            <p>
              <strong>Mon-Sat: 11AM</strong> - 23PM<br>
              Sunday: Closed
            </p>
          </div>
        </div>

        <div class="col-lg-3 col-md-6 footer-links">
          <h4>Follow Us</h4>
          <div class="social-links d-flex">
            <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
            <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
            <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
            <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
          </div>
        </div>

      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>W Solar Power Installer</span></strong>. 
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/yummy-bootstrap-restaurant-website-template/ -->
        Designed by <a >Xamarin Squad-074 824 8292</a>
      </div>
    </div>

  </footer><!-- End Footer -->
  <!-- End Footer -->

  <a href="#" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <div id="preloader"></div>

  <div class="modal fade" id="myModal3" role="dialog">
      <div class="modal-dialog modal-sm">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Add New director</h4>
          </div>
          <div class="modal-body">
            <form action="phpScripts/adminOparation.php" method="POST"  enctype="multipart/form-data">
             <input type="text" class="form-control" name="type" id="type" value="addDirector" hidden>
              <div class="form-group mt-3">
                <input type="text" class="form-control" name="name" id="name" placeholder="Director Full Names" required>
              </div>
               <div class="form-group mt-3">
                 <input type="text" class="form-control" name="position" id="position" placeholder="Director Position" required>
               </div>
               <div class="form-group mt-3">
                  <input required type="file" id="pic" class="form-content"  name="pic"  />
               </div>
               <div class="form-group mt-3">
                 <button style="width:100%" class="btn btn-success" type="submit">Add New Director</button>
               </div>
             </form>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>
   </div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>