<?php

    function OpenCon()
    {
      //change the db to live one
      $dbhost ="localhost";
      $dbuser = "root";
      $dbpass = "";
      $db = "w_solar_power_installer";
      
      $conn = new mysqli($dbhost, $dbuser, $dbpass,$db ) or die("Connect failed: %s\n". $conn->error);
      return $conn;
    }

    

      function CloseCon($conn)
      {
        $conn -> close();
      }
 ?>
